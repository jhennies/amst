# -*- coding: utf-8 -*-
# tifffile/__init__.py

from .tifffile import __doc__, __all__, __version__, main
from .tifffile import *
